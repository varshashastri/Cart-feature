package ee.service;

import ee.Exception.InvalidProductException;
import ee.Exception.RestApiException;
import ee.model.Product;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Service
public class ProductPriceService {
    @Value("${price.url.prefix}")
    private String priceUrlPrefix;

    @Value("${price.url.suffix}")
    private String priceUrlSuffix;

    @Autowired
    private RestTemplate template;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    public Float getProductPrice(@NonNull final String productName) throws InvalidProductException, RestApiException {
        Product product = null;
        try {
            product = template.getForEntity(priceUrlPrefix + productName + priceUrlSuffix, Product.class).getBody();

        } catch(final RestClientException ex) {
            logger.debug(ex.getMessage());
            logger.trace(Arrays.toString(ex.getStackTrace()));
            throw new RestApiException("Equal Experts api threw an exception");
        }

        if (product == null) {
            throw new InvalidProductException("Product does not exist");
        }
        return product.getPrice();
    }
}
