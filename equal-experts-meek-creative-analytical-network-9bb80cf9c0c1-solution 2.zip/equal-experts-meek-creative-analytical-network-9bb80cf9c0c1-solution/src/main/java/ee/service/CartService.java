package ee.service;

import ee.Exception.InvalidProductException;
import ee.Exception.InvalidQuantityException;
import ee.Exception.RestApiException;
import ee.model.CartState;
import ee.model.CartTotals;
import ee.model.Product;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.Map;
import java.util.Optional;

@Service
public class CartService {

    @Value("${tax}")
    private float tax;

    @Autowired
    private CartState cartState;
    @Autowired
    private ProductPriceService productPriceService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public void addProductToCart(@NonNull final String productName, @NonNull final Integer quantity) throws InvalidQuantityException, InvalidProductException, RestApiException {
        if (quantity > 0) {
            final Float price = productPriceService.getProductPrice(productName);
            cartState.getItems().merge(new Product(productName, price), quantity, Integer::sum);
            logger.debug("added items to cart");
        } else {
            logger.debug("ProductQuantity mentioned is" + quantity);
            throw new InvalidQuantityException("Product quantity must be a positive integer");
        }
    }

    public CartTotals getCartTotals() {
        final Float subtotal = getRoundOff(calcTotal());
        final Float totalTax = getRoundOff(tax * subtotal);
        final Float finalTotal = getRoundOff(tax * subtotal + subtotal);

        return CartTotals.builder()
                .cart(cartState)
                .tax(totalTax)
                .subtotal(subtotal)
                .finalTotal(finalTotal)
                .build();
    }

    private float getRoundOff(Float number) {
        return (float) Math.round(number * 100f) / 100f;
    }

    private Float calcTotal() {
        return Optional.ofNullable(cartState).map(CartState::getItems)
                .map(Map::keySet)
                .map(products -> products
                        .stream()
                        .map(product -> cartState.getItems().get(product) * product.getPrice())
                        .reduce(Float::sum)
                        .orElse(0f))
                .orElse(0f);
    }
}
