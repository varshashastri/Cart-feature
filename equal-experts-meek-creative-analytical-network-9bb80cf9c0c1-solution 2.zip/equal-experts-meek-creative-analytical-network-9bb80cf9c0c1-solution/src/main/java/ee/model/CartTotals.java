package ee.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties
public class CartTotals {
    @JsonProperty
    private CartState cart;
    @JsonProperty
    private Float subtotal;
    @JsonProperty
    private Float tax;
    @JsonProperty
    private Float finalTotal;

}
