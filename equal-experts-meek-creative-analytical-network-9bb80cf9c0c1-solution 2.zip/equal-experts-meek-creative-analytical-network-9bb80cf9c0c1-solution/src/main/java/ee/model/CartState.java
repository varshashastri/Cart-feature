package ee.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Map;

@JsonIgnoreProperties
@Data
@Builder
public class CartState {

    @JsonProperty
    private Map<Product, Integer> items;
}
