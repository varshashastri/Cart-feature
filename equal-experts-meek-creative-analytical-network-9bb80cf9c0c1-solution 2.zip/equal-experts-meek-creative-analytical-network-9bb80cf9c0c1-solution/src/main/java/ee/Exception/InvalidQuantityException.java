package ee.Exception;

public class InvalidQuantityException extends Exception {
    public InvalidQuantityException(final String message) {
        super(message);
    }
}
