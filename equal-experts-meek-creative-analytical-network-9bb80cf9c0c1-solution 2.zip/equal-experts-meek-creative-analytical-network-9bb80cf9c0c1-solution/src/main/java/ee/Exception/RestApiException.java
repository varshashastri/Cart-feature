package ee.Exception;

public class RestApiException extends Exception {
    public RestApiException(final String message) {
        super(message);
    }
}
