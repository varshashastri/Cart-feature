package ee.Exception;


public class InvalidProductException extends Exception {
    public InvalidProductException(final String message) {
        super(message);
    }
}
