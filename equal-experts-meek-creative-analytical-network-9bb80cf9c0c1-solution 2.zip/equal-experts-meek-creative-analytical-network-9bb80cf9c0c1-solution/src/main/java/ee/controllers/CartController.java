package ee.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ee.Exception.InvalidProductException;
import ee.Exception.InvalidQuantityException;
import ee.Exception.RestApiException;
import ee.model.CartTotals;
import ee.service.CartService;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CartController {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CartService cartService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PostMapping("/addProductToCart/{productName}/{quantity}")
    public ResponseEntity<String> addProductToCart(@PathVariable("productName") @NonNull final String productName, @PathVariable("quantity") final int quantity) {
        try {
            cartService.addProductToCart(productName, quantity);
            logger.info("Added item {} quantity {} to cart", productName, quantity);
            return ResponseEntity.ok().build();
        } catch (final InvalidProductException ex) {
            logger.debug(ex.getMessage());
            logger.debug("Please check inputs and provide valid product name");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Invalid product name");
        } catch (final InvalidQuantityException ex) {
            logger.debug(ex.getMessage());
            logger.debug("Please check inputs and provide positive quanity");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Invalid product quantity");
        } catch (final RestApiException e) {
            logger.debug(e.getMessage());
            logger.debug("Please check inputs");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Invalid product name");
        }
    }

    @GetMapping("/cartState")
    public ResponseEntity<String> getCartState() {
        try {
            CartTotals cartTotals = cartService.getCartTotals();
            String jsonCart = objectMapper.writeValueAsString(cartTotals);
            logger.info("Getting the cart totals");
            return ResponseEntity.ok(jsonCart);
        } catch (JsonProcessingException e) {
            logger.debug(e.getMessage());
            logger.debug("Unable to convert cart totals into json");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Unable to convert to json");
        }
    }
}