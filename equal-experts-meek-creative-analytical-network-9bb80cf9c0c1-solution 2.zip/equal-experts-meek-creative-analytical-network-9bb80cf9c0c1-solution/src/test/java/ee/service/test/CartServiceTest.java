package ee.service.test;

import ee.Exception.InvalidProductException;
import ee.Exception.InvalidQuantityException;
import ee.Exception.RestApiException;
import ee.model.CartState;
import ee.model.Product;
import ee.service.CartService;
import ee.service.ProductPriceService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
public class CartServiceTest {
    @Autowired
    @Mock
    private ProductPriceService productPriceService;

    @Autowired
    @Mock
    private CartState cartState;

    @Autowired
    @InjectMocks
    private CartService cartService;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void givenGetCartTotalsIsCalled_whenNothingInCart_ZeroIsReturned() {
        Assert.assertEquals(0f, cartService.getCartTotals().getSubtotal(), 0.0);
        Assert.assertEquals(0f, cartService.getCartTotals().getTax(), 0.0);
        Assert.assertEquals(0f, cartService.getCartTotals().getFinalTotal(), 0.0);
    }

    @Test
    public void givenGetCartTotalsIsCalled_whenitemsInCart_RightSubtotalIsReturned() {
        Map<Product, Integer> items = new HashMap<>();
        items.put(Product.builder().title("test").price(10f).build(), 1);
        when(cartState.getItems()).thenReturn(items);
        Assert.assertEquals(10f, cartService.getCartTotals().getSubtotal(), 0.0);
    }

    @Test
    public void givenAddToCartIsCalled_SuccessfullyAddedWithoutExceptions() throws InvalidProductException, InvalidQuantityException, RestApiException {
        when(productPriceService.getProductPrice(any())).thenReturn(10f);
        Map<Product, Integer> items = new HashMap<>();
        items.put(Product.builder().title("test").price(10f).build(), 1);
        when(cartState.getItems()).thenReturn(items);
        cartService.addProductToCart("test", 2);
    }

    @Test(expected = InvalidQuantityException.class)
    public void givenGetCartTotalsIsCalled_whenNegativeQuantity_ThrowsInvalidQuantityException() throws InvalidProductException, InvalidQuantityException, RestApiException {
        when(productPriceService.getProductPrice(any())).thenReturn(10f);
        Map<Product, Integer> items = new HashMap<>();
        items.put(Product.builder().title("test").price(10f).build(), 1);
        when(cartState.getItems()).thenReturn(items);
        cartService.addProductToCart("test", -1);
    }

    @Test(expected = InvalidProductException.class)
    public void givenGetCartTotalsIsCalled_whenInvalidProduct_ThrowsInvalidProductException() throws InvalidProductException, InvalidQuantityException, RestApiException {
        when(productPriceService.getProductPrice(any())).thenThrow(InvalidProductException.class);
        Map<Product, Integer> items = new HashMap<>();
        items.put(Product.builder().title("test").price(10f).build(), 1);
        when(cartState.getItems()).thenReturn(items);
        cartService.addProductToCart("test", 2);
    }


    @Test(expected = RestApiException.class)
    public void givenGetCartTotalsIsCalled_whenEERestApiDoesNotWork_ThrowsRestApiException() throws InvalidProductException, InvalidQuantityException, RestApiException {
        when(productPriceService.getProductPrice(any())).thenThrow(RestApiException.class);
        Map<Product, Integer> items = new HashMap<>();
        items.put(Product.builder().title("test").price(10f).build(), 1);
        when(cartState.getItems()).thenReturn(items);
        cartService.addProductToCart("test", 2);
    }

}
