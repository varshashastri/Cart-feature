package ee.service.test;

import ee.Exception.InvalidProductException;
import ee.Exception.RestApiException;
import ee.model.CartState;
import ee.model.Product;
import ee.service.CartService;
import ee.service.ProductPriceService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
public class ProductPriceServiceTest {

    @Value("${price.url.prefix}")
    private String priceUrlPrefix;

    @Value("${price.url.suffix}")
    private String priceUrlSuffix;
    @Autowired
    @Mock
    private RestTemplate restTemplate;
    @Autowired
    @InjectMocks
    private ProductPriceService productPriceService;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void whenGetProductPriceIsCalled_returnsProductPrice() throws InvalidProductException, RestApiException {
        when(restTemplate.getForEntity(priceUrlPrefix + "productName" + priceUrlSuffix, Product.class)).thenReturn(ResponseEntity.ok(Product.builder().title("productName").price(10f).build()));
        Assert.assertEquals(10f, productPriceService.getProductPrice("productName"), 0.0);
    }
    @Test(expected = InvalidProductException.class)
    public void whenGetProductPriceIsCalledForInvalidProduct_ThrowsInvalidProductException() throws InvalidProductException, RestApiException {
        when(restTemplate.getForEntity(priceUrlPrefix + "productName" + priceUrlSuffix, Product.class)).thenReturn(ResponseEntity.ok(null));
        productPriceService.getProductPrice("productName");
    }
    @Test(expected = RestApiException.class)
    public void whenGetProductPriceIsCalledAndRestApiDoesNotWork_ThrowsRestApiException() throws InvalidProductException, RestApiException {
        when(restTemplate.getForEntity(priceUrlPrefix + "productName" + priceUrlSuffix, Product.class)).thenThrow(RestClientException.class);
        productPriceService.getProductPrice("productName");
    }
}
