package ee.controller.test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ee.Exception.InvalidProductException;
import ee.Exception.InvalidQuantityException;
import ee.Exception.RestApiException;
import ee.controllers.CartController;
import ee.model.CartState;
import ee.model.CartTotals;
import ee.model.Product;
import ee.service.CartService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@SpringBootTest
public class CartControllerTest {
    @Autowired
    @Mock
    private CartService cartService;

    @Autowired
    @Mock
    private ObjectMapper objectMapper;

    @Autowired
    @InjectMocks
    private CartController cartController;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void givengetCartStateIsCalled_whenValidInputs_CorrectValueIsReturned() throws JsonProcessingException {
        ObjectMapper mapper1 = new ObjectMapper();
        Product product = Product.builder().price(1.1f).title("product1").build();
        Map<Product, Integer> items = new HashMap<>();
        items.put(product, 2);
        CartTotals cartTotals = CartTotals.builder().cart(CartState.builder().items(items).build()).finalTotal(10f).tax(12.5f).build();
        when(cartService.getCartTotals()).thenReturn(cartTotals);
        String expectedVal = mapper1.writeValueAsString(cartTotals);
        when(objectMapper.writeValueAsString(any())).thenReturn(expectedVal);
        Assert.assertEquals(expectedVal, cartController.getCartState().getBody());
    }

    @Test
    public void givengetCartStateIsCalled_whenJsonProcessingFails_throwsInternalServerError() throws JsonProcessingException {
        Product product = Product.builder().price(1.1f).title("product1").build();
        Map<Product, Integer> items = new HashMap<>();
        items.put(product, 2);
        CartTotals cartTotals = CartTotals.builder().cart(CartState.builder().items(items).build()).finalTotal(10f).tax(12.5f).build();
        when(cartService.getCartTotals()).thenReturn(cartTotals);
        when(objectMapper.writeValueAsString(cartTotals)).thenThrow(new JsonProcessingException("test") {
        });
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, cartController.getCartState().getStatusCode());
    }

    @Test
    public void givenaddProductToCartIsCalled_productIsAdded() {
        ResponseEntity<String> response = cartController.addProductToCart("product", 2);
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void givenaddProductToCartIsCalled_WhenInvalidProduct_returnsInternalServerError() throws InvalidQuantityException, InvalidProductException, RestApiException {
        doThrow(InvalidProductException.class).when(cartService).addProductToCart(any(), any());
        ResponseEntity<String> response = cartController.addProductToCart("product", 2);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void givenaddProductToCartIsCalled_WhenInvalidQuanity_returnsInternalServerError() throws InvalidQuantityException, InvalidProductException, RestApiException {
        doThrow(InvalidQuantityException.class).when(cartService).addProductToCart(any(), any());
        ResponseEntity<String> response = cartController.addProductToCart("product", 2);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void givenaddProductToCartIsCalled_WhenRestApiDoesNotWork_returnsInternalServerError() throws InvalidQuantityException, InvalidProductException, RestApiException {
        doThrow(RestApiException.class).when(cartService).addProductToCart(any(), any());
        ResponseEntity<String> response = cartController.addProductToCart("product", 2);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

}
